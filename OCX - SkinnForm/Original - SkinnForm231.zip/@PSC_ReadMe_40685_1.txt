Title: SkinnableForm ver 1.1 with 16 skins!!!
Description: This is a new version of Skinnable Form project with 16 skins and some bugs fixed. This project gives your VB project the ability of changing skins easy as it can possible. Now beside rectangle forms you can have rounded and polygon forms.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=40685&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
